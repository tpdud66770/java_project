package Frame;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class MainFrame extends JFrame implements ActionListener {
	    public JPanel panel[] = new JPanel[4];
	    private JPanel Header;
	    public JButton btn[] = new JButton[4];
	    public JPanel currentPanel = null;
	    public MainFrame() {
	        setTitle("Test");
	        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        setSize(400, 300);
	        setLayout(new BorderLayout());
	        
	        Header = new JPanel();
	        panel[0] = new bodyPanel1(this);
	        panel[1] = new bodyPanel2();
	        panel[2] = new bodyPanel3();
	        panel[3] = new bodyPanel4();

	        
	        for(int i = 0; i < 4 ; i++) {
	        	btn[i] = new JButton("버튼" + i);
	        	Header.add(btn[i]);
	        	btn[i].addActionListener(this);
	        }
	        // Create first panel with a button to switch to the second panel

	        // Create second panel with a button to switch to the first panel


	        // Start with the first panel
	        add(Header,BorderLayout.NORTH);
	        add(panel[0], BorderLayout.CENTER);
	        
	      
	        currentPanel = panel[0];
	        setVisible(true);
	    }
		@Override
		public void actionPerformed(ActionEvent e) {
			Object obj = e.getSource();
			for(int i = 0 ; i < 4 ; i++ ) {
				if(obj == btn[i]) {
					switchToPanel(panel[i]);
				}
			}
		}
	    private void switchToPanel(JPanel panel) {
	        remove(currentPanel); // Remove the second panel
	        add(panel, BorderLayout.CENTER); // Add the first panel
	        revalidate(); // Refresh the frame        
	        repaint();    // Repaint the frame

	        currentPanel = panel;
	    }


	    public static void main(String[] args) {
	    	new MainFrame();
	    }
	}
