package Frame;

import java.awt.Color;

import javax.swing.JPanel;

public class bodyPanel2 extends JPanel{
	public bodyPanel2() {
		setBackground(Color.green);
	}
}
