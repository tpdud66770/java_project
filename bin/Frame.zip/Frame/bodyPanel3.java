package Frame;

import java.awt.Color;

import javax.swing.JPanel;

public class bodyPanel3 extends JPanel{
	public bodyPanel3() {
		setBackground(Color.blue);
	}
}
