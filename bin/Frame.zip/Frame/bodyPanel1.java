package Frame;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class bodyPanel1 extends JPanel implements ActionListener{
	JButton btn = new JButton("예약");
	MainFrame frame;
	public bodyPanel1(MainFrame frame) {
		this.frame = frame;
		setBackground(Color.red);
		add(btn);
		btn.addActionListener(this);
		
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		frame.remove(frame.currentPanel);
		frame.add(frame.panel[1]);
		frame.currentPanel = frame.panel[1];
		frame.repaint();
		frame.revalidate();
	}
}
