package Frame;

import java.awt.Color;

import javax.swing.JPanel;

public class bodyPanel4 extends JPanel{
	public bodyPanel4() {
		setBackground(Color.black);
	}
}
