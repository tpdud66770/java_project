package restaurant;

public class SalesBean {
	private int sales_num;
	private int sales_menu;
	private int sales_amount;
	private int sales_price;
	private String sales_date;
	
	public int getSales_num() {
		return sales_num;
	}
	public void setSales_num(int sales_num) {
		this.sales_num = sales_num;
	}
	public int getSales_menu() {
		return sales_menu;
	}
	public void setSales_menu(int sales_menu) {
		this.sales_menu = sales_menu;
	}
	public int getSales_amount() {
		return sales_amount;
	}
	public void setSales_amount(int sales_amount) {
		this.sales_amount = sales_amount;
	}
	public int getSales_price() {
		return sales_price;
	}
	public void setSales_price(int sales_price) {
		this.sales_price = sales_price;
	}
	public String getSales_date() {
		return sales_date;
	}
	public void setSales_date(String sales_date) {
		this.sales_date = sales_date;
	}
	
	
}
