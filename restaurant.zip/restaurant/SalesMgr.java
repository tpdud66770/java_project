package restaurant;

import java.nio.file.attribute.AclEntry;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

import database.DBConnectionMgr;

public class SalesMgr {
	
	private DBConnectionMgr pool;
	Connection con;
	PreparedStatement pstmt;
	ResultSet rs;
	String sql ="";
	
	public SalesMgr() {
		try {
			pool = DBConnectionMgr.getInstance();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public Vector<SalesBean> getMenus(){
		Vector<SalesBean> vlist = new Vector<SalesBean>();
		try {
			con = pool.getConnection();
			sql = "select * from menu";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				SalesBean bean = new SalesBean();
				bean.setSales_num(rs.getInt(1));
				bean.setSales_menu(rs.getInt(2));
				bean.setSales_amount(rs.getInt(3));
				bean.setSales_price(rs.getInt(4));
				bean.setSales_date(rs.getString(5));
				vlist.add(bean);
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return vlist;
	}
	
	public SalesBean getMenu(int menu_num){
		SalesBean bean = new SalesBean();
		try {
			con = pool.getConnection();
			sql = "select * from menu where menu_num = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, menu_num);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				bean.setSales_num(rs.getInt(1));
				bean.setSales_menu(rs.getInt(2));
				bean.setSales_amount(rs.getInt(3));
				bean.setSales_price(rs.getInt(4));
				bean.setSales_date(rs.getString(5));
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return bean;
	}
	
	
}
