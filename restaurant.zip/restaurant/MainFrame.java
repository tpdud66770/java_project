package restaurant;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class MainFrame extends JFrame {
    public JPanel[] panel = new JPanel[3];
    public JPanel currentPanel = null;

    public MainFrame() {
        this.setSize(584, 836);
        this.setLayout(null); 

        // 패널 추가
 
        panel[0].setBounds(0, 0, 584, 836);
        panel[1] = new manager_menu();
        panel[1].setBounds(0, 0, 584, 836);
        panel[2]=new manager_sales();
        panel[2].setBounds(0, 0, 584, 836);
        this.add(panel[0]);
        currentPanel = panel[0]; 
        this.setVisible(true);
    }

}