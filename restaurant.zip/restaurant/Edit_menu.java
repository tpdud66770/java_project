package restaurant;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

import com.mysql.cj.x.protobuf.MysqlxNotice.Frame;

public class Edit_menu extends JFrame{
	Color gray=new Color(220,220,220);
	JPanel jp,jp1,jp2;
	JTextField mn,mc;
	JLabel imageLabel;
	JButton uploadBtn,editBtn;
	File selectedFile;
	Font font1 = new Font(Font.DIALOG, Font.BOLD, 13);
    Font font2 = new Font(Font.DIALOG, Font.BOLD, 12);
	public Edit_menu() {
		super("메뉴 수정");				
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocation(500, 380);
		setSize(400, 400);
		setBackground(Color.white);
		
		jp = new JPanel();
        jp.setLayout(null);
        jp.setBounds(0, 0, 400, 400); //메인 패널 위치와 크기
        jp.setBackground(Color.white);
               		
		jp1 = new JPanel();
        jp1.setLayout(null);
        jp1.setBounds(50, 20, 300, 150); 
        jp1.setBackground(Color.white);
        
        //이미지 불러오기
        imageLabel = new JLabel("이미지를 업로드", SwingConstants.CENTER);
        imageLabel.setFont(font1);
        imageLabel.setBounds(40,10,150,150);
        uploadBtn = new JButton("Upload Image");//사진추가
        uploadBtn.setBounds(240,130,20,20);
        uploadBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser fileChooser = new JFileChooser();
                int option = fileChooser.showOpenDialog(null);

                if (option == JFileChooser.APPROVE_OPTION) {
                    selectedFile = fileChooser.getSelectedFile();

                    // 이미지를 라벨에 표시
                    ImageIcon imageIcon = new ImageIcon(selectedFile.getAbsolutePath());
                    imageLabel.setIcon(imageIcon);
                    imageLabel.setText("");
                }
            }
        });
        
        jp1.add(imageLabel);
        jp1.add(uploadBtn);
        
        jp2 = new JPanel();
        jp2.setLayout(null);
        jp2.setBackground(gray);
        jp2.setBounds(50, 200, 300, 80); 
        mn=new JTextField();
        mn.setFont(font1);
        mn.setBackground(gray);
        mn.setBorder(javax.swing.BorderFactory.createEmptyBorder());
        mn.setBounds(10,10,150,25);
        mn.setText("존맛탱파스타");

        mc=new JTextField();
        mc.setFont(font2);
        mc.setBackground(gray);
        mc.setBounds(10, 40, 150, 25);
        mc.setForeground(Color.white);
        mc.setBorder(javax.swing.BorderFactory.createEmptyBorder());
        mc.setText("99,999");
        jp2.add(mn);
        jp2.add(mc);
        
        //수정하기 버튼
        editBtn=new JButton("수정하기");
        editBtn.setForeground(Color.white);
        editBtn.setBackground(Color.black);
        editBtn.setBounds(280, 300, 85, 30);
        editBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                saveImageToRestaurantFolder(selectedFile);
            }
        });
        jp.add(editBtn);
        
        jp.add(jp1);
        jp.add(jp2);
        this.add(jp);
        setVisible(true);
	}
	
	public void saveImageToRestaurantFolder(File selectedFile) {
        try {
            // 현재 프로젝트 경로를 기준으로 restaurant 폴더로 설정
            Path projectDir = Paths.get(System.getProperty("user.dir"));
            Path restaurantFolder = projectDir.resolve("restaurant");
            Path destinationPath = restaurantFolder.resolve(selectedFile.getName());
        
            Files.copy(selectedFile.toPath(), destinationPath);
            JOptionPane.showMessageDialog(this, "메뉴 저장!");
            dispose();
        } catch (IOException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "같은 파일 존재");
        }
    }
	
	public static void main(String[] args) {
        new Edit_menu();
    }

}
