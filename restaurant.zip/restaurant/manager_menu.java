package restaurant;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

import restaurant.MainFrame;

import javax.swing.JLabel;

public class manager_menu extends JPanel implements ActionListener{
	RoundedCheckBox ch1,ch2,ch3,ch4;
    RoundedButton logOutBtn,prevBtn,nextBtn;
    JButton editBtn;
    JPanel jp,jp1,jp2;
    JLabel logolb,lb1,lb2,lb3,lb4;//이미지 라벨
    JLabel mn1,mn2,mn3,mn4;//메뉴이름 라벨
    JLabel mc1,mc2,mc3,mc4;//메뉴가격 라벨
    Font font1 = new Font(Font.DIALOG, Font.BOLD, 13);
    Font font2 = new Font(Font.DIALOG, Font.BOLD, 12);

    public manager_menu() {
        this.setLayout(null); 

        jp = new JPanel();
        jp.setLayout(null);
        jp.setBounds(0, 0, 584, 836); //메인 패널 위치와 크기
        jp.setBackground(Color.white);
        
        //젤 위의 패널
        jp1 = new JPanel();
        jp1.setLayout(null);
        jp1.setBounds(10, 10, 544, 100); 
        jp1.setBackground(Color.white);
        logOutBtn=new RoundedButton("로그아웃");
        logOutBtn.setBounds(450, 30, 60, 30);
        //이미지 리사이징
        ImageIcon icon = new ImageIcon("restaurant\\logo.png");            
        Image img = icon.getImage();            
        Image updateImg = img.getScaledInstance(170, 100, Image.SCALE_SMOOTH);           
        ImageIcon updateIcon = new ImageIcon(updateImg);            
        logolb = new JLabel(updateIcon);
        logolb.setBounds(10, 25, 100, 50);
        jp1.add(logOutBtn);
        jp1.add(logolb);
        
        jp2 = new JPanel();
        jp2.setLayout(null);
        jp2.setBounds(10, 120, 484, 800); 
        jp2.setBackground(Color.white);
        
        //체크박스
        ch1=new RoundedCheckBox();
        ch1.setBounds(50,100,15,15);
        ch2=new RoundedCheckBox();
        ch2.setBounds(50,230,15,15);
        ch3=new RoundedCheckBox();
        ch3.setBounds(50,360,15,15);
        ch4=new RoundedCheckBox();
        ch4.setBounds(50,490,15,15);
        jp2.add(ch1);
        jp2.add(ch2);
        jp2.add(ch3);
        jp2.add(ch4);
        
        //이미지
        ImageIcon food1 = new ImageIcon("restaurant\\fd1.png");            
        Image img1 = food1.getImage();            
        Image updateImg1 = img1.getScaledInstance(170, 100, Image.SCALE_SMOOTH);           
        ImageIcon updateIcon1 = new ImageIcon(updateImg1);            
        lb1 = new JLabel(updateIcon1);
        ImageIcon food2 = new ImageIcon("restaurant\\fd2.png");            
        Image img2 = food2.getImage();            
        Image updateImg2 = img2.getScaledInstance(170, 100, Image.SCALE_SMOOTH);           
        ImageIcon updateIcon2 = new ImageIcon(updateImg2);            
        lb2 = new JLabel(updateIcon1);
        ImageIcon food3 = new ImageIcon("restaurant\\fd3.png");            
        Image img3 = food3.getImage();            
        Image updateImg3 = img3.getScaledInstance(170, 100, Image.SCALE_SMOOTH);           
        ImageIcon updateIcon3 = new ImageIcon(updateImg3);            
        lb3 = new JLabel(updateIcon3);
        ImageIcon food4 = new ImageIcon("restaurant\\fd4.png");            
        Image img4 = food4.getImage();            
        Image updateImg4 = img4.getScaledInstance(170, 100, Image.SCALE_SMOOTH);           
        ImageIcon updateIcon4 = new ImageIcon(updateImg4);            
        lb4 = new JLabel(updateIcon4);
        lb1.setBounds(90, 30, 150, 150);
        lb2.setBounds(90, 160, 150, 150);
        lb3.setBounds(90, 290, 150, 150);
        lb4.setBounds(90, 420, 150, 150);
        jp2.add(lb1);
        jp2.add(lb2);
        jp2.add(lb3);
        jp2.add(lb4);
        
        //메뉴 이름
        mn1=new JLabel("갈릭 립아이");
        mn1.setBounds(300, 70, 200, 50);
        mn1.setFont(font1);
        mn2=new JLabel("짐붐바 스테이크");
        mn2.setBounds(300, 200, 200, 50);
        mn2.setFont(font1);
        mn3=new JLabel("치폴레 치킨 샐러드");
        mn3.setBounds(300, 330, 200, 50);
        mn3.setFont(font1);
        mn4=new JLabel("립레츠&치즈 필라프");
        mn4.setBounds(300, 460, 200, 50);
        mn4.setFont(font1);
        jp2.add(mn1);
        jp2.add(mn2);
        jp2.add(mn3);
        jp2.add(mn4);
        
        //메뉴 가격
        mc1=new JLabel("38,900원");
        mc1.setBounds(300, 90, 200, 50);
        mc1.setFont(font2);
        mc1.setForeground(Color.gray);
        mc2=new JLabel("47,900원");
        mc2.setBounds(300, 220, 200, 50);
        mc2.setFont(font2);
        mc2.setForeground(Color.gray);
        mc3=new JLabel("23,900원");
        mc3.setBounds(300, 350, 200, 50);
        mc3.setFont(font2);
        mc3.setForeground(Color.gray);
        mc4=new JLabel("29,900원");
        mc4.setBounds(300, 480, 200, 50);
        mc4.setFont(font2);
        mc4.setForeground(Color.gray);
        jp2.add(mc1);
        jp2.add(mc2);
        jp2.add(mc3);
        jp2.add(mc4);
        
        //이전 다음 화살표
        prevBtn=new RoundedButton("prev");
        prevBtn.setBounds(50, 570, 50, 30);
        nextBtn=new RoundedButton("next");
        nextBtn.setBounds(434, 570, 50, 30);
        jp2.add(prevBtn);
        jp2.add(nextBtn);
        
        //수정하기 버튼
        editBtn=new JButton("수정하기");
        editBtn.setForeground(Color.white);
        //editBtn.setBorderPainted(false);
        //editBtn.setContentAreaFilled(false);
        editBtn.setBackground(Color.black);
        editBtn.setBounds(228, 620, 85, 30);
        jp2.add(editBtn);
        editBtn.addActionListener(this);
        
        jp.add(jp1); 
        jp.add(jp2);
        this.add(jp);
        this.setVisible(true);  
        
    }
    
    @Override
	   public void paint(Graphics g) {
		   super.paint(g);
		   g.drawLine(20, 100, 544, 100);

	   }
    
    
    @Override
    public void actionPerformed(ActionEvent e) {
    	Object o=e.getSource();
    	if(o==editBtn) {
    		Edit_menu g1 = new Edit_menu();
    		g1.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    		g1.setVisible(true);
    	}
    	
    }
}
    
