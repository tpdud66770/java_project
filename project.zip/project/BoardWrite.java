package project;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

public class BoardWrite extends JPanel {
    private ImageIcon logo;
    public static List<Post> posts = new ArrayList<>();   // 게시글 임시저장
    private BoardMain mainFrame; // 기존 BoradMain 창을 참조하는 변수
    private JLabel imagePreviewLabel; // 이미지 미리보기 라벨
    private File selectedImageFile; // 선택된 이미지 파일 저장
    private int mileage = 0; // 초기 마일리지
    private JLabel mileageLabel; // 마일리지 점수를 표시할 라벨
    
    public static class Post {
        private String title;
        private String content;
        private String userId;
        private String date;
        private String imagePath; 

        public Post(String userId, String date, String title, String content, String imagePath) {
            this.userId = userId;
            this.date = date;
            this.title = title;
            this.content = content;
            this.imagePath = imagePath;  
        }

        public String getUserId() {
            return userId;
        }

        public String getDate() {
            return date;
        }

        public String getTitle() {
            return title;
        }

        public String getContent() {
            return content;
        }

        public String getImagePath() { 
            return imagePath;
        }
    }
    
    
    public void addPost(Post post) {
        posts.add(post);
    }
    
    // BoradWrite 생성자에 BoradMain 인스턴스를 받는 생성자 추가
    public BoardWrite(BoardMain mainFrame) {
        this.mainFrame = mainFrame;

        setSize(584, 836);
        setLayout(null);
        
        JPanel topPanel = new JPanel();
        topPanel.setBounds(0, 0, 584, 50);
        topPanel.setLayout(null);
        add(topPanel);
        topPanel.setBackground(Color.WHITE);
        topPanel.setBorder(new LineBorder(Color.LIGHT_GRAY, 1, false)); // 밑부분에 선 추가

        logo = new ImageIcon("project/logo.png");
        Image scaledLogo = logo.getImage().getScaledInstance(150, 40, Image.SCALE_SMOOTH);
        JLabel logoLabel = new JLabel(new ImageIcon(scaledLogo));
        logoLabel.setBounds(10, 5, 150, 40); // 로고를 상단 패널 크기에 맞춤
        topPanel.add(logoLabel);

        JButton reviewButton = new ReviewButton();
        topPanel.add(reviewButton);

        JButton boardButton = new BoardButton();
        topPanel.add(boardButton);

        JButton logoutButton = new LogoutButton();
        topPanel.add(logoutButton);
        
        // 마일리지 라벨
        mileageLabel = new JLabel("마일리지: " + mileage + "점");
        mileageLabel.setBounds(270, 10, 150, 30); // 마일리지 라벨 위치 설정
        mileageLabel.setFont(reviewButton.getFont()); // 리뷰 버튼과 동일한 폰트 설정
        topPanel.add(mileageLabel);

        // 내용 패널
        JPanel contentPanel = new JPanel();
        contentPanel.setBounds(10, 60, 554, 650);
        contentPanel.setLayout(null);
        contentPanel.setBackground(Color.WHITE);
        contentPanel.setBorder(new LineBorder(new Color(211, 211, 211), 1));
        add(contentPanel);

        JLabel titleLabel = new JLabel("제목");
        titleLabel.setBounds(20, 20, 40, 20);
        titleLabel.setFont(new Font("Malgun Gothic", Font.BOLD, 14));
        contentPanel.add(titleLabel);

        JTextField titleField = new JTextField();
        titleField.setBounds(20, 50, 520, 30);
        titleField.setFont(new Font("Malgun Gothic", Font.PLAIN, 14));
        contentPanel.add(titleField);

        // 이미지 미리보기 라벨
        imagePreviewLabel = new JLabel();
        imagePreviewLabel.setBounds(30, 90, 150, 150);
        contentPanel.add(imagePreviewLabel);

        ImageIcon imageIcon = new ImageIcon("project/image.png");
        Image scaledImageIcon = imageIcon.getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH);
        JButton imageButton = new JButton(new ImageIcon(scaledImageIcon));
        imageButton.setBounds(20, 250, 30, 30);
        imageButton.setBackground(Color.WHITE);
        contentPanel.add(imageButton);

        JTextArea board_content = new JTextArea();
        board_content.setBounds(30, 290, 500, 300);
        board_content.setFont(new Font("Malgun Gothic", Font.PLAIN, 14));
        board_content.setLineWrap(true);
        board_content.setWrapStyleWord(true);

        JScrollPane scrollPane = new JScrollPane(board_content);
        scrollPane.setBounds(20, 290, 520, 310);
        contentPanel.add(scrollPane);

        // 하단 패널
        JPanel bottomPanel = new JPanel();
        bottomPanel.setBounds(0, 740, 584, 60);
        bottomPanel.setLayout(null);
        bottomPanel.setBackground(Color.WHITE);
        add(bottomPanel);

        RoundedButton submitButton = new RoundedButton("등록");
        submitButton.setBounds(242, 10, 100, 40);
        submitButton.setBackground(Color.BLACK);
        submitButton.setForeground(Color.WHITE);
        submitButton.setFont(new Font("Malgun Gothic", Font.BOLD, 14));
        bottomPanel.add(submitButton);

        // 이미지 버튼 클릭 이벤트
        imageButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser fileChooser = new JFileChooser();
                int returnValue = fileChooser.showOpenDialog(null);
                if (returnValue == JFileChooser.APPROVE_OPTION) {
                    selectedImageFile = fileChooser.getSelectedFile();
                    // 이미지 미리보기 설정
                    ImageIcon previewIcon = new ImageIcon(new ImageIcon(selectedImageFile.getPath()).getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH));
                    imagePreviewLabel.setIcon(previewIcon);
                }
            }
        });

        // 등록 버튼 클릭 이벤트
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String title = titleField.getText();
                String content = board_content.getText();
                String userId = "작성자"; // 예시로 작성자 이름을 설정합니다.
                String date = new SimpleDateFormat("yyyy.MM.dd").format(new Date()); // 현재 날짜로 설정

                // 새로운 게시글 생성 및 저장
                Post newPost = new Post(userId, date, title, content, selectedImageFile != null ? selectedImageFile.getPath() : null);
                posts.add(newPost);

                // BoradMain 화면 갱신
                if (mainFrame != null) {
                    mainFrame.updatePosts(posts);
                    mainFrame.setVisible(true);
                }

                JOptionPane.showMessageDialog(null, "게시글이 등록되었습니다!");
                mainFrame.mainFrame.switchToPanel(mainFrame);
            }
        });

        setVisible(true);
    }
     
}
