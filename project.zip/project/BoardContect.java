package project;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;

public class BoardContect extends JPanel {
    private ImageIcon logo;
    private int mileage = 0; // 초기 마일리지
    private JLabel mileageLabel; // 마일리지 점수를 표시할 라벨
    
    private ArrayList<String> comments;    // 댓글 리스트
    private JPanel commentPanel;  // 댓글 표시할 패널
    private JScrollPane commentScrollPane; // 댓글 스크롤 패널
    private JTextField commentInput; // 댓글 입력 필드

    public BoardContect(BoardMain mainFrame, BoardWrite.Post post) {
        setSize(584, 836);

        setLayout(null);
        setBackground(Color.WHITE);

        JPanel topPanel = new JPanel();
        topPanel.setBounds(0, 0, 584, 50);
        topPanel.setLayout(null);
        add(topPanel);
        topPanel.setBackground(Color.WHITE);
        topPanel.setBorder(new LineBorder(Color.LIGHT_GRAY, 1, false)); // 밑부분에 선 추가

        logo = new ImageIcon("project/logo.png");
        Image scaledLogo = logo.getImage().getScaledInstance(150, 40, Image.SCALE_SMOOTH);
        JLabel logoLabel = new JLabel(new ImageIcon(scaledLogo));
        logoLabel.setBounds(10, 5, 150, 40); // 로고를 상단 패널 크기에 맞춤
        topPanel.add(logoLabel);

        JButton reviewButton = new ReviewButton();
        topPanel.add(reviewButton);

        JButton boardButton = new BoardButton();
        topPanel.add(boardButton);
        boardButton.addActionListener(new ActionListener() { 
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				mainFrame.mainFrame.switchToPanel(mainFrame);
			}
		});

        JButton logoutButton = new LogoutButton();
        topPanel.add(logoutButton);

        // 마일리지 라벨
        mileageLabel = new JLabel("마일리지: " + mileage + "점");
        mileageLabel.setBounds(270, 10, 150, 30); // 마일리지 라벨 위치 설정
        mileageLabel.setFont(reviewButton.getFont()); // 리뷰 버튼과 동일한 폰트 설정
        topPanel.add(mileageLabel);

        // 작성자 정보(회원 아이디)
        JLabel userIdLabel = new JLabel(post.getUserId());
        userIdLabel.setFont(new Font("Malgun Gothic", Font.PLAIN, 14));
        userIdLabel.setBounds(35, 100, 200, 20);
        add(userIdLabel);

        // 작성일자
        JLabel dateLabel = new JLabel(post.getDate());
        dateLabel.setFont(new Font("Malgun Gothic", Font.PLAIN, 14));
        dateLabel.setBounds(35, 125, 200, 20);
        add(dateLabel);

        // 게시글 제목
        JLabel titleLabel = new JLabel(post.getTitle());
        titleLabel.setFont(new Font("Malgun Gothic", Font.BOLD, 20));
        titleLabel.setBounds(35, 150, 300, 20);
        add(titleLabel);

        // 이미지 추가
        if (post.getImagePath() != null && !post.getImagePath().isEmpty()) {
        	 ImageIcon postImage = new ImageIcon(post.getImagePath());
             Image originalImage = postImage.getImage();

             
             int width = originalImage.getWidth(null);
             int height = originalImage.getHeight(null);
             float aspectRatio = (float) width / height;

             int newWidth = 130;
             int newHeight = 130;

             if (aspectRatio > 1) { // 가로가 더 긴 경우
                 newHeight = (int) (newWidth / aspectRatio);
             } else if (aspectRatio < 1) { // 세로가 더 긴 경우
                 newWidth = (int) (newHeight * aspectRatio);
             }

             Image scaledImage = originalImage.getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH);
             JLabel imageLabel = new JLabel(new ImageIcon(scaledImage));
             imageLabel.setBounds(35, 190, 130, 130); 
             add(imageLabel);
            
            JTextArea contentArea = new JTextArea(post.getContent());
            contentArea.setFont(new Font("Malgun Gothic", Font.PLAIN, 14));
            contentArea.setBounds(35, 330, 500, 200);
            contentArea.setLineWrap(true);
            contentArea.setWrapStyleWord(true);
            contentArea.setEditable(false); // 내용 수정 불가
            add(contentArea);
        } else {  // 이미지 없을 때
            JTextArea contentArea = new JTextArea(post.getContent());
            contentArea.setFont(new Font("Malgun Gothic", Font.PLAIN, 14));
            contentArea.setBounds(35, 175, 500, 200);
            contentArea.setLineWrap(true);
            contentArea.setWrapStyleWord(true);
            contentArea.setEditable(false);
            add(contentArea);
        }

        comments = new ArrayList<>(); // 댓글 리스트 초기화
        
        // 댓글 패널
        commentPanel = new JPanel();
        commentPanel.setLayout(new BoxLayout(commentPanel, BoxLayout.Y_AXIS));
        commentPanel.setBackground(Color.WHITE);

        // 댓글 스크롤 패널
        commentScrollPane = new JScrollPane(commentPanel);
        commentScrollPane.setBounds(20, 450, 540, 200);
        commentScrollPane.setBorder(null);
        commentScrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER); // 가로 스크롤 제거
        add(commentScrollPane);

        // 댓글 입력 필드
        commentInput = new JTextField();
        commentInput.setBounds(20, 670, 540, 30);
        add(commentInput);

        // 댓글 쓰기 버튼 추가
        RoundedButton comentButton = new RoundedButton("댓글 쓰기");
        comentButton.setBounds(240, 720, 100, 30);
        comentButton.setBackground(Color.BLACK);
        comentButton.setForeground(Color.WHITE);
        comentButton.setFont(new Font("Malgun Gothic", Font.BOLD, 12));
        comentButton.setBorder(new LineBorder(Color.BLACK, 1)); // 외곽선 추가
        add(comentButton);
        
        // 댓글 쓰기 버튼 액션 리스너
        comentButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String newComment = commentInput.getText();
                if (!newComment.isEmpty()) {
                    comments.add(0, newComment); // 댓글 리스트에 추가 (최근 댓글이 위로 오게)
                    displayComments(); // 댓글 목록 업데이트
                    commentInput.setText(""); // 입력 필드 초기화
                }
            }
        });

        setVisible(true);
    }
    
    // 댓글 목록을 표시 메소드
    private void displayComments() {
        commentPanel.removeAll(); // 기존 댓글 제거

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy.MM.dd HH:mm"); // 날짜 형식 설정

        for (String comment : comments) {
            JPanel singleCommentPanel = new JPanel();
            singleCommentPanel.setLayout(null); // 레이아웃을 null로 설정하여 위치를 직접 지정
            singleCommentPanel.setBackground(Color.WHITE);

            JLabel nameLabel = new JLabel("작성자 아이디"); // 실제 사용자 이름으로 변경 필요
            nameLabel.setFont(new Font("Malgun Gothic", Font.BOLD, 12));
            nameLabel.setBounds(10, 10, 100, 15); // 위치 조정
            singleCommentPanel.add(nameLabel);

            JLabel timeLabel = new JLabel(dateFormat.format(new Date())); // 현재 시각을 포맷에 맞춰 표시
            timeLabel.setFont(new Font("Malgun Gothic", Font.PLAIN, 12));
            timeLabel.setBounds(110, 10, 200, 15); // 위치 조정
            singleCommentPanel.add(timeLabel);
            
            JTextArea commentText = new JTextArea(comment);
            commentText.setLineWrap(true);
            commentText.setWrapStyleWord(true);
            commentText.setEditable(false);
            commentText.setBackground(null); 
            commentText.setBorder(null); 
            commentText.setBounds(20, 35, 500, 40); // 위치 조정
            singleCommentPanel.add(commentText);
            
            JSeparator separator = new JSeparator();
            separator.setBounds(10, 80, 520, 1); // 위치와 크기 조정
            separator.setForeground(Color.BLACK); // 구분선 검은색으로 설정
            singleCommentPanel.add(separator);

            singleCommentPanel.setPreferredSize(new java.awt.Dimension(540, 90)); // 패널 크기 조정
            commentPanel.add(singleCommentPanel);
        }
        
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                commentScrollPane.getVerticalScrollBar().setValue(0);
            }
        });

        commentPanel.revalidate();
        commentPanel.repaint();
    }

}
