package log;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import com.mysql.cj.xdevapi.AddResultBuilder;

import Frame.MainFrame;
import Frame.ReserveSetDialog;
import database.ReservationBean;
import project.BoardMain;
import restaurant.manager_main;

public class OutbackApp extends JFrame{
    public String userId;
    public OutbackApp mainFrame = this;
	public static int WIDTH = 584;
	public static int HEIGHT = 786;
    public JPanel panel[] = new JPanel[4];
    private JPanel Header;
    public JButton btn[] = new JButton[4];
    public JPanel currentPanel = null;
    public ReservationBean reserveBean;
    public OutbackApp(){
    	
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(584, 836);
        this.setLocationRelativeTo(null); // Center the frame

        // Main panel for card layout
        JPanel cardPanel = new JPanel(new CardLayout());

        // Home Panel
        JPanel homePanel = new JPanel();
        homePanel.setBackground(Color.WHITE);
        homePanel.setLayout(new BoxLayout(homePanel, BoxLayout.Y_AXIS));

        // Logo
        JLabel logoLabel = new JLabel(new ImageIcon(OutbackApp.class.getResource("/log/outback_logo.png")));
        logoLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        homePanel.add(Box.createVerticalStrut(50));
        homePanel.add(logoLabel);

        // Buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(Color.WHITE);
        RoundedButton loginButton = new RoundedButton("로그인");
        RoundedButton guestLoginButton = new RoundedButton("비회원 로그인");
        RoundedButton guestReservationButton = new RoundedButton("비회원 예약확인");
        RoundedButton signupButton = new RoundedButton("회원가입");

        // Set all button background colors to black
        loginButton.setBackground(Color.BLACK);
        guestLoginButton.setBackground(Color.BLACK);
        guestReservationButton.setBackground(Color.BLACK);
        signupButton.setBackground(Color.BLACK);

        // Set button text color to white
        loginButton.setForeground(Color.WHITE);
        guestLoginButton.setForeground(Color.WHITE);
        guestReservationButton.setForeground(Color.WHITE);
        signupButton.setForeground(Color.WHITE);

        buttonPanel.add(loginButton);
        buttonPanel.add(guestLoginButton);
        buttonPanel.add(guestReservationButton);
        buttonPanel.add(signupButton);
        buttonPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        homePanel.add(Box.createVerticalStrut(20));
        homePanel.add(buttonPanel);

        // Add home panel to card panel
        cardPanel.add(homePanel, "Home");

        // Login Panel
        JPanel loginPanel = createLoginPanel(cardPanel);
        cardPanel.add(loginPanel, "Login");

        // Guest Login Panel
        JPanel guestLoginPanel = createGuestLoginPanel(cardPanel);
        cardPanel.add(guestLoginPanel, "GuestLogin");

        // Guest Reservation Panel
        JPanel guestReservationPanel = createGuestReservationPanel(cardPanel);
        cardPanel.add(guestReservationPanel, "GuestReservation");

        // Signup Panel
        JPanel signupPanel = createSignupPanel(cardPanel);
        cardPanel.add(signupPanel, "Signup");

        // OutbackReservationSystem Panel
        JPanel reservationSystemPanel = createReservationSystemPanel(cardPanel);
        cardPanel.add(reservationSystemPanel, "ReservationSystem");

        // Add card panel to frame
        this.add(cardPanel);
        this.setVisible(true);

        // Button actions
        loginButton.addActionListener(e -> showPanel(cardPanel, "Login"));
        guestLoginButton.addActionListener(e -> showPanel(cardPanel, "GuestLogin"));
        guestReservationButton.addActionListener(e -> showPanel(cardPanel, "GuestReservation"));
        signupButton.addActionListener(e -> showPanel(cardPanel, "Signup"));
    }

    // 로그인 패널 생성 메서드
    public JPanel createLoginPanel(JPanel cardPanel) {
        JPanel loginPanel = new JPanel(new GridBagLayout());
        loginPanel.setBackground(Color.WHITE);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel idLabel = new JLabel("아이디:");
        gbc.gridx = 0;
        gbc.gridy = 0;
        loginPanel.add(idLabel, gbc);

        JTextField usernameField = new JTextField(15);
        gbc.gridx = 1;
        loginPanel.add(usernameField, gbc);

        JLabel pwLabel = new JLabel("비밀번호:");
        gbc.gridx = 0;
        gbc.gridy = 1;
        loginPanel.add(pwLabel, gbc);

        JPasswordField passwordField = new JPasswordField(15);
        gbc.gridx = 1;
        loginPanel.add(passwordField, gbc);

        JCheckBox adminCheckBox = new JCheckBox("관리자로 로그인");
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        loginPanel.add(adminCheckBox, gbc);

        // RoundedButton for Login Button with similar style as Back Button
        RoundedButton loginButton = new RoundedButton("로그인");
        loginButton.setBackground(Color.BLACK);
        loginButton.setForeground(Color.WHITE);
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        loginPanel.add(loginButton, gbc);

        loginButton.addActionListener(e -> {
            userId = usernameField.getText();
            String password = new String(passwordField.getPassword());
            boolean isAdmin = adminCheckBox.isSelected();

            UserService userService = new UserService();
            boolean success;

            if (isAdmin) {
                success = userService.loginAdmin(userId, password);
                if (success) {
                    JOptionPane.showMessageDialog(loginPanel, "관리자 로그인 성공!");
                    switchToPanel(new manager_main(this));  // 관리자 전용 페이지로 이동
                } else {
                    JOptionPane.showMessageDialog(loginPanel, "관리자 로그인 실패: ID 또는 비밀번호 오류");
                }
            } else {
                success = userService.loginUser(userId, password);
                if (success) {
                    JOptionPane.showMessageDialog(loginPanel, "로그인 성공!");
                    showPanel(cardPanel, "ReservationSystem");  // 사용자 페이지로 이동
                } else {
                    JOptionPane.showMessageDialog(loginPanel, "로그인 실패: ID 또는 비밀번호 오류");
                }
            }
        });

        // RoundedButton for Back Button
        RoundedButton backButton = new RoundedButton("뒤로가기");
        backButton.setBackground(Color.BLACK);
        backButton.setForeground(Color.WHITE);
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        loginPanel.add(backButton, gbc);

        backButton.addActionListener(e -> showPanel(cardPanel, "Home"));

        return loginPanel;
    }

    public JPanel createGuestLoginPanel(JPanel cardPanel) {
        JPanel guestLoginPanel = new JPanel(new GridBagLayout());
        guestLoginPanel.setBackground(Color.WHITE);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel nameLabel = new JLabel("이름:");
        gbc.gridx = 0;
        gbc.gridy = 0;
        guestLoginPanel.add(nameLabel, gbc);

        JTextField nameField = new RoundedTextField(15);  // Use RoundedTextField
        gbc.gridx = 1;
        guestLoginPanel.add(nameField, gbc);

        JLabel phoneLabel = new JLabel("전화번호:");
        gbc.gridx = 0;
        gbc.gridy = 1;
        guestLoginPanel.add(phoneLabel, gbc);

        JTextField phoneField = new RoundedTextField(15);  // Use RoundedTextField
        gbc.gridx = 1;
        guestLoginPanel.add(phoneField, gbc);

        RoundedButton guestLoginButton = new RoundedButton("비회원 로그인");
        guestLoginButton.setBackground(Color.BLACK);
        guestLoginButton.setForeground(Color.WHITE);
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        guestLoginPanel.add(guestLoginButton, gbc);

        guestLoginButton.addActionListener(e -> {
            String name = nameField.getText();
            String phone = phoneField.getText();

            UserService userService = new UserService();
            boolean success = userService.guestLogin(name, phone);

            if (success) {
                JOptionPane.showMessageDialog(guestLoginPanel, "비회원 로그인 성공!");
                showPanel(cardPanel, "ReservationSystem"); // Move to ReservationSystem
            } else {
                JOptionPane.showMessageDialog(guestLoginPanel, "비회원 로그인 실패: 이름 또는 전화번호가 잘못되었습니다.");
            }
        });

        RoundedButton backButton = new RoundedButton("뒤로가기");
        backButton.setBackground(Color.BLACK);
        backButton.setForeground(Color.WHITE);
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        guestLoginPanel.add(backButton, gbc);

        backButton.addActionListener(e -> showPanel(cardPanel, "Home"));

        return guestLoginPanel;
    }

   	 public JPanel createGuestReservationPanel(JPanel cardPanel) {
        JPanel guestReservationPanel = new JPanel(new GridBagLayout());
        guestReservationPanel.setBackground(Color.WHITE);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel reservationLabel = new JLabel("예약번호:");
        gbc.gridx = 0;
        gbc.gridy = 0;
        guestReservationPanel.add(reservationLabel, gbc);

        JTextField reservationField = new RoundedTextField(15);  // Use RoundedTextField
        gbc.gridx = 1;
        guestReservationPanel.add(reservationField, gbc);

        RoundedButton checkReservationButton = new RoundedButton("예약확인");
        checkReservationButton.setBackground(Color.BLACK);
        checkReservationButton.setForeground(Color.WHITE);
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        guestReservationPanel.add(checkReservationButton, gbc);

        checkReservationButton.addActionListener(e -> {
            String reservationNumber = reservationField.getText();

            // 예약 확인 로직 추가
            if (reservationNumber.isEmpty()) {
                JOptionPane.showMessageDialog(guestReservationPanel, "예약번호를 입력하세요.");
            } else {
                // 예시: 데이터베이스에서 예약 정보를 확인하는 로직 추가
                JOptionPane.showMessageDialog(guestReservationPanel, "예약 확인 시도: 예약번호: " + reservationNumber);
            }
        });

        RoundedButton backButton = new RoundedButton("뒤로가기");
        backButton.setBackground(Color.BLACK);
        backButton.setForeground(Color.WHITE);
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        guestReservationPanel.add(backButton, gbc);

        backButton.addActionListener(e -> showPanel(cardPanel, "Home"));

        return guestReservationPanel;
    }

    public JPanel createSignupPanel(JPanel cardPanel) {
        JPanel signupPanel = new JPanel(new GridBagLayout());
        signupPanel.setBackground(Color.WHITE);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel nameLabel = new JLabel("이름:");
        gbc.gridx = 0;
        gbc.gridy = 0;
        signupPanel.add(nameLabel, gbc);

        JTextField nameField = new RoundedTextField(15);  // Use RoundedTextField
        gbc.gridx = 1;
        signupPanel.add(nameField, gbc);

        JLabel idLabel = new JLabel("아이디:");
        gbc.gridx = 0;
        gbc.gridy = 1;
        signupPanel.add(idLabel, gbc);

        JTextField usernameField = new RoundedTextField(15);  // Use RoundedTextField
        gbc.gridx = 1;
        signupPanel.add(usernameField, gbc);

        JLabel pwLabel = new JLabel("비밀번호:");
        gbc.gridx = 0;
        gbc.gridy = 2;
        signupPanel.add(pwLabel, gbc);

        JPasswordField passwordField = new JPasswordField(15);  // JPasswordField as it is
        gbc.gridx = 1;
        signupPanel.add(passwordField, gbc);

        JLabel confirmPwLabel = new JLabel("비밀번호 확인:");
        gbc.gridx = 0;
        gbc.gridy = 3;
        signupPanel.add(confirmPwLabel, gbc);

        JPasswordField confirmPasswordField = new JPasswordField(15);  // JPasswordField as it is
        gbc.gridx = 1;
        signupPanel.add(confirmPasswordField, gbc);

        JLabel phoneLabel = new JLabel("전화번호:");
        gbc.gridx = 0;
        gbc.gridy = 4;
        signupPanel.add(phoneLabel, gbc);

        JTextField phoneField = new RoundedTextField(15);  // Use RoundedTextField
        gbc.gridx = 1;
        signupPanel.add(phoneField, gbc);

        RoundedButton signupButton = new RoundedButton("회원가입");
        signupButton.setBackground(Color.BLACK);
        signupButton.setForeground(Color.WHITE);
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        signupPanel.add(signupButton, gbc);

        signupButton.addActionListener(e -> {
            String name = nameField.getText();
            String userId = usernameField.getText();
            String password = new String(passwordField.getPassword());
            String confirmPassword = new String(confirmPasswordField.getPassword());
            String phone = phoneField.getText();

            if (!password.equals(confirmPassword)) {
                JOptionPane.showMessageDialog(signupPanel, "비밀번호가 일치하지 않습니다.");
                return;
            }

            UserService userService = new UserService();
            boolean success = userService.registerUser(userId, password, name, phone);

            if (success) {
                JOptionPane.showMessageDialog(signupPanel, "회원가입 성공!");
                showPanel(cardPanel, "ReservationSystem"); // Move to ReservationSystem
            } else {
                JOptionPane.showMessageDialog(signupPanel, "회원가입 실패: 사용자 이름이 중복되었거나, DB 오류가 발생했습니다.");
            }
        });

        RoundedButton backButton = new RoundedButton("뒤로가기");
        backButton.setBackground(Color.BLACK);
        backButton.setForeground(Color.WHITE);
        gbc.gridy = 6;
        gbc.gridwidth = 2;
        signupPanel.add(backButton, gbc);

        backButton.addActionListener(e -> showPanel(cardPanel, "Home"));

        return signupPanel;
    }

    public JPanel createReservationSystemPanel(JPanel cardPanel) {
        JPanel reservationSystemPanel = new JPanel();
        reservationSystemPanel.setBackground(Color.WHITE);
        reservationSystemPanel.setLayout(new BoxLayout(reservationSystemPanel, BoxLayout.Y_AXIS));

        // Logo
        JLabel logoLabel = new JLabel(new ImageIcon(OutbackApp.class.getResource("/log/outback_logo.png")));
        logoLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        reservationSystemPanel.add(Box.createVerticalStrut(50)); // Add some space at the top
        reservationSystemPanel.add(logoLabel);

        // First row of buttons (Reservation)
        JPanel reservationPanel = new JPanel();
        reservationPanel.setBackground(Color.WHITE);
        RoundedButton makeReservationButton = new RoundedButton("예약하기");
        RoundedButton checkReservationButton = new RoundedButton("예약확인");

        // Setting background and foreground for reservation buttons
        makeReservationButton.setBackground(Color.BLACK);
        makeReservationButton.setForeground(Color.WHITE);
        checkReservationButton.setBackground(Color.BLACK);
        checkReservationButton.setForeground(Color.WHITE);

        reservationPanel.add(makeReservationButton);
        reservationPanel.add(checkReservationButton);

        // Second row of buttons (Board, Review, Logout)
        JPanel otherOptionsPanel = new JPanel();
        otherOptionsPanel.setBackground(Color.WHITE);
        RoundedButton boardButton = new RoundedButton("게시판");
        RoundedButton reviewButton = new RoundedButton("리뷰");
        RoundedButton logoutButton = new RoundedButton("로그아웃");

        // Setting background and foreground for other buttons
        boardButton.setBackground(Color.WHITE);
        boardButton.setForeground(Color.BLACK);
        reviewButton.setBackground(Color.WHITE);
        reviewButton.setForeground(Color.BLACK);
        logoutButton.setBackground(Color.WHITE);
        logoutButton.setForeground(Color.BLACK);

        otherOptionsPanel.add(boardButton);
        otherOptionsPanel.add(reviewButton);
        otherOptionsPanel.add(logoutButton);

        // Adding panels to reservation system panel
        reservationSystemPanel.add(Box.createVerticalStrut(20));
        reservationSystemPanel.add(reservationPanel);
        reservationSystemPanel.add(Box.createVerticalStrut(20));
        reservationSystemPanel.add(otherOptionsPanel);

        // Button actions
        makeReservationButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new ReserveSetDialog(mainFrame);
            }
        });
        reviewButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new ReviewMain(userId);
            }
        });

        checkReservationButton.addActionListener(e -> JOptionPane.showMessageDialog(reservationSystemPanel, "예약확인 버튼 클릭됨"));
        boardButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				switchToPanel(new BoardMain(mainFrame));
			}
		});
        logoutButton.addActionListener(e -> {
            JOptionPane.showMessageDialog(reservationSystemPanel, "로그아웃되었습니다.");
            showPanel(cardPanel, "Home"); // Return to Home Panel
        });

        return reservationSystemPanel;
    }

    public void showPanel(JPanel cardPanel, String panelName) {
        CardLayout cl = (CardLayout) cardPanel.getLayout();
        cl.show(cardPanel, panelName);
        currentPanel = cardPanel;
    }
    
    public void switchToPanel(JPanel panel) {
        remove(currentPanel);
        add(panel, BorderLayout.CENTER); 
        revalidate();
        repaint();

        currentPanel = panel;
    }
    public static void main(String[] args) {
		new OutbackApp();
	}
}
