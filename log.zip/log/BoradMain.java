package log;

public class BoradMain {

	public static void main(String[] args) {
		
	}

}
