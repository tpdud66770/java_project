package log;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.util.ArrayList;
import java.util.List;

public class ReviewMain extends JFrame {

    private ImageIcon logo;
    private String userId; // 로그인 시스템 연동
    private List<Review> reviews = new ArrayList<>();
    private JPanel reviewPanel;
    private int selectStar = 0;  // 사용자가 택한 별점
    private ImageIcon selectedImage = null; // 선택된 이미지 아이콘
    private int mileage = 0; // 초기 마일리지
    private JLabel mileageLabel; // 마일리지 점수를 표시할 라벨
    private String reviewId = "asdasd";
    public String selectedImagePath ;
    
    
    public ReviewMain(String userId) {
    	this.userId = userId;
        setTitle("리뷰");
        setSize(584, 836);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        getContentPane().setBackground(Color.WHITE);

        JPanel topPanel = new JPanel();
        topPanel.setBounds(0, 0, 584, 50);
        topPanel.setLayout(null);
        add(topPanel);
        topPanel.setBackground(Color.WHITE);
        topPanel.setBorder(new LineBorder(Color.LIGHT_GRAY, 1, false)); // 밑부분에 선 추가

        logo = new ImageIcon("project/logo.png");
        Image scaledLogo = logo.getImage().getScaledInstance(150, 40, Image.SCALE_SMOOTH);
        JLabel logoLabel = new JLabel(new ImageIcon(scaledLogo));
        logoLabel.setBounds(10, 5, 150, 40); // 로고를 상단 패널 크기에 맞춤
        topPanel.add(logoLabel);

        // 리뷰 버튼
        JButton reviewButton = new ReviewButton();
        topPanel.add(reviewButton);

        // 게시판 버튼
        JButton boardButton = new BoardButton1();
        topPanel.add(boardButton);

        // 마일리지 라벨
        mileageLabel = new JLabel("마일리지: " + mileage + "점");
        mileageLabel.setBounds(250, 10, 150, 30); // 마일리지 라벨 위치 설정
        mileageLabel.setFont(reviewButton.getFont()); // 리뷰 버튼과 동일한 폰트 설정
        topPanel.add(mileageLabel);

        // 로그아웃 버튼
        JButton logoutButton = new LogoutButton();
        topPanel.add(logoutButton);

        RoundedButton1 writeReviewButton = new RoundedButton1("리뷰 작성");
        writeReviewButton.setBounds(240, 746, 100, 30);
        writeReviewButton.setBackground(Color.BLACK);
        writeReviewButton.setForeground(Color.WHITE);
        writeReviewButton.setFont(new Font("Malgun Gothic", Font.BOLD, 12));
        writeReviewButton.setBorder(new LineBorder(Color.BLACK, 1)); // 외곽선 추가
        add(writeReviewButton);

        writeReviewButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (selectedImage != null) {
                    // 리뷰 제출 로직
                    selectedImage = null; // 이미지 초기화
                }
                showReviewDialog();
            }
        });

        reviewPanel = new JPanel();
        reviewPanel.setBackground(Color.WHITE);
        reviewPanel.setLayout(new BoxLayout(reviewPanel, BoxLayout.Y_AXIS));

        JScrollPane scrollPane = new JScrollPane(reviewPanel);
        scrollPane.setBounds(0, 50, 584, 680);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16); // 스크롤 속도 조절
        scrollPane.setBorder(null);
        add(scrollPane);

        setVisible(true);
    }

    private void showReviewDialog() {
        JDialog reviewDialog = new JDialog(this, "리뷰 작성", Dialog.ModalityType.APPLICATION_MODAL);
        reviewDialog.setSize(400, 400); // 다이얼로그 크기를 늘림
        reviewDialog.setLayout(null);
        reviewDialog.getContentPane().setBackground(Color.WHITE);

        RoundedTextField reviewTextArea = new RoundedTextField(20);
        reviewTextArea.setBounds(10, 10, 365, 100);
        reviewTextArea.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        reviewDialog.add(reviewTextArea);

        // 사용자 정보 및 날짜 표시
        JLabel userInfoLabel = new JLabel();
        userInfoLabel.setText(userId + "   " + LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy.MM.dd")));
        userInfoLabel.setBounds(10, 300, 200, 30);
        userInfoLabel.setFont(new Font("Malgun Gothic", Font.PLAIN, 12));
        reviewDialog.add(userInfoLabel);

        // 5개의 별 버튼 생성 및 클릭 이벤트 추가
        JPanel starPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        starPanel.setBounds(10, 120, 365, 80);
        starPanel.setBackground(Color.WHITE);
        reviewDialog.add(starPanel);

        JButton[] stars = new JButton[5];
        for (int i = 0; i < 5; i++) {
            stars[i] = new JButton(new StarIcon(30, 30, Color.GRAY));
            stars[i].setBorderPainted(false);
            stars[i].setContentAreaFilled(false);
            final int starIndex = i;
            stars[i].addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    selectStar = starIndex + 1; // 선택한 별점 저장
                    updateStarIcons(stars); // 선택한 별에 따라 아이콘 업데이트
                }
            });
            starPanel.add(stars[i]);
        }

        // 이미지 추가 버튼
        RoundedButton1 imageButton = new RoundedButton1("이미지 추가");
        imageButton.setBounds(170, 300, 90, 30);
        imageButton.setBackground(Color.BLACK);
        imageButton.setForeground(Color.WHITE);
        imageButton.setFont(new Font("Malgun Gothic", Font.BOLD, 12));
        reviewDialog.add(imageButton);

        JLabel imagePreviewLabel = new JLabel();
        imagePreviewLabel.setBounds(50, 180, 100, 100); // 이미지 미리보기 위치
        reviewDialog.add(imagePreviewLabel);

        imageButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser fileChooser = new JFileChooser();
                int result = fileChooser.showOpenDialog(reviewDialog);
                if (result == JFileChooser.APPROVE_OPTION) {
                    File selectedFile = fileChooser.getSelectedFile();
                    ImageIcon imageIcon = new ImageIcon(selectedFile.getPath());
                    selectedImagePath = selectedFile.getPath();

                    // 이미지 크기 조정
                    Image scaledImage = imageIcon.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
                    selectedImage = new ImageIcon(scaledImage);
                    imagePreviewLabel.setIcon(selectedImage); // 이미지 미리보기 설정
                }
            }
        });

        RoundedButton1 submitButton = new RoundedButton1("등록하기");
        submitButton.setBounds(270, 300, 90, 30);
        submitButton.setBackground(Color.BLACK);
        submitButton.setForeground(Color.WHITE);
        submitButton.setFont(new Font("Malgun Gothic", Font.BOLD, 12));
        submitButton.setBorder(new LineBorder(Color.BLACK, 1)); // 외곽선 추가
        reviewDialog.add(submitButton);

        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String reviewText = reviewTextArea.getText();
                int rating = selectStar;
                byte[] imageBytes = null;

                if (selectedImage != null) {
                    try {
                        // ImageIcon을 바이트 배열로 변환
                        BufferedImage bufferedImage = new BufferedImage(
                            selectedImage.getIconWidth(), 
                            selectedImage.getIconHeight(), 
                            BufferedImage.TYPE_INT_RGB
                        );
                        Graphics g = bufferedImage.createGraphics();
                        selectedImage.paintIcon(null, g, 0, 0);
                        g.dispose();
                        
                        ByteArrayOutputStream baos = new ByteArrayOutputStream();
                        ImageIO.write(bufferedImage, "png", baos);
                        imageBytes = baos.toByteArray();
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }

                // 리뷰 데이터를 데이터베이스에 삽입
                
                new InsertReviewIntoDatabase().insertReview(userId, reviewText, rating, selectedImagePath);

                // 리뷰 리스트와 UI 업데이트
                Review review = new Review(userId, LocalDate.now(), reviewText, rating, selectedImage);
                reviews.add(review);
                updateMileage(500);
                updateReviewPanel();
                reviewDialog.dispose();
            }
        });

        reviewDialog.setLocationRelativeTo(this);
        reviewDialog.setVisible(true);
        
    }

    private void updateMileage(int points) {
        mileage += points; // 마일리지 추가
        mileageLabel.setText("마일리지: " + mileage + "점"); // 마일리지 라벨 업데이트
    }

    // 사용자가 선택한 별에 따라 아이콘의 색상 변경
    private void updateStarIcons(JButton[] stars) {
        for (int i = 0; i < stars.length; i++) {
            if (i < selectStar) {
                stars[i].setIcon(new StarIcon(30, 30, Color.RED)); // 선택된 별은 빨간색으로 표시
            } else {
                stars[i].setIcon(new StarIcon(30, 30, Color.GRAY)); // 선택되지 않은 별은 회색으로 표시
            }
        }
    }

    private void updateReviewPanel() {
        reviewPanel.removeAll();  // 기존의 모든 리뷰 패널을 제거합니다.

        for (Review review : reviews) {  // 저장된 모든 리뷰를 반복합니다.
            JPanel containerPanel = new JPanel(null);  // 레이아웃을 null로 설정하여 수동으로 배치
            containerPanel.setBackground(Color.WHITE);
            containerPanel.setPreferredSize(new Dimension(550, 150));  // 패널의 크기를 설정합니다.

            // 이미지 패널 (빨간색 윤곽 영역)
            JPanel imagePanel = new JPanel(null);
            imagePanel.setBounds(10, 10, 100, 100);  // 이미지 위치와 크기를 설정 (좌표 설정)
            imagePanel.setBackground(Color.WHITE);
            if (review.getImage() != null) {
                // 이미지를 패널 크기에 맞게 조정
                Image scaledImage = review.getImage().getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
                ImageIcon scaledIcon = new ImageIcon(scaledImage);
                JLabel reviewImageLabel = new JLabel(scaledIcon);
                reviewImageLabel.setBounds(0, 0, 100, 100);  // 이미지 라벨의 위치와 크기 설정
                imagePanel.add(reviewImageLabel);  // 이미지 라벨을 이미지 패널에 추가
            }
            containerPanel.add(imagePanel);  // 이미지를 컨테이너 패널에 추가

            // 텍스트 및 별점 패널 (파란색 윤곽 영역)
            JPanel textPanel = new JPanel(null);
            textPanel.setBounds(130, 10, 400, 100);  // 텍스트 패널의 위치와 크기를 설정
            textPanel.setBackground(Color.WHITE);

            // 별점
            JLabel starLabel = new JLabel(generateStars(review.getRating()));
            starLabel.setFont(new Font("Malgun Gothic", Font.PLAIN, 14));
            starLabel.setForeground(Color.RED);
            starLabel.setBounds(0, 0, 200, 30);  // 별점 라벨의 위치와 크기 설정
            textPanel.add(starLabel);  // 텍스트 패널에 별점 추가

            // 리뷰 텍스트
            JLabel reviewTextLabel = new JLabel(review.getText());
            reviewTextLabel.setFont(new Font("Malgun Gothic", Font.PLAIN, 12));
            reviewTextLabel.setBounds(0, 30, 400, 30);  // 리뷰 텍스트의 위치와 크기 설정
            textPanel.add(reviewTextLabel);  // 텍스트 패널에 리뷰 텍스트 추가

            // 사용자 정보
            JLabel userInfoLabel = new JLabel("<html><b>" + review.getUserId() + "</b><br>"
                    + review.getDate().format(DateTimeFormatter.ofPattern("yyyy.MM.dd")) + "</html>");
            userInfoLabel.setFont(new Font("Malgun Gothic", Font.PLAIN, 12));
            userInfoLabel.setBounds(0, 60, 400, 30);  // 사용자 정보의 위치와 크기 설정
            textPanel.add(userInfoLabel);  // 텍스트 패널에 사용자 정보 추가

            containerPanel.add(textPanel);  // 텍스트 패널을 컨테이너 패널에 추가
            reviewPanel.add(containerPanel, 0);  // 최종적으로 리뷰 패널에 추가
        }

        reviewPanel.revalidate();  // 리뷰 패널을 다시 그립니다.
        reviewPanel.repaint();  // 리뷰 패널을 다시 그립니다.
    }

    private String generateStars(int rating) {
        StringBuilder stars = new StringBuilder();
        for (int i = 0; i < 5; i++) {
            if (i < rating) {
                stars.append("★"); // 선택된 별은 채워진 별로 표시
            } else {
                stars.append("☆"); // 선택되지 않은 별은 빈 별로 표시
            }
        }
        return stars.toString();
    }

}

class Review {
    private String userId;
    private LocalDate date;
    private String text;
    private int rating;
    private ImageIcon image; // 추가된 이미지 필드

    public Review(String userId, LocalDate date, String text, int rating, ImageIcon image) {
        this.userId = userId;
        this.date = date;
        this.text = text;
        this.rating = rating;
        this.image = image;
    }

    public String getUserId() {
        return userId;
    }

    public LocalDate getDate() {
        return date;
    }

    public String getText() {
        return text;
    }

    public int getRating() {
        return rating;
    }

    public ImageIcon getImage() {
        return image;
    }
}
